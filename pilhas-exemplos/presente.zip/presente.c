#include "presente.h"
#include <stdio.h>
#include <stdlib.h>

Gift* readGifts(int n)
{
    Gift *gifts = malloc(n * sizeof(Gift));

    for (int i = 0; i < n; i++)
    {
        scanf("%ld %ld %ld %ld", &gifts[i].i, &gifts[i].h, &gifts[i].w, &gifts[i].l);
        gifts[i].v = gifts[i].h * gifts[i].w * gifts[i].l;
    }
    return gifts;
}

void quickSort(Gift* gift, int n, int r){
    if(n < r){
        int i = partition(gift, n, r);
        quickSort(gift, n, i-1);
        quickSort(gift, i+1, r);
    }
}

int partition(Gift* gift, int n, int r){
    
    Gift x = gift[r]; 
    int i = n - 1;
    
    for(int j = n; j < r; j++){
        if(gift[j].v <= x.v){
            i++;
            switx(gift, j, i);
        }
    }
    switx(gift, i+1, r);

    return i;
}

int switx(Gift *gift, int n, int r){
    Gift temp = gift[n];
	gift[n] = gift[r];
	gift[r] = temp;
}

void print(Gift* gift, int k, int n){
    Gift *ordenedGifts = malloc(n * sizeof(Gift));
    for(int i = n-1; k > 0; i--, k--)
        printf("%ld ", gift[i].i);

    printf("\n");
    free(ordenedGifts);
}